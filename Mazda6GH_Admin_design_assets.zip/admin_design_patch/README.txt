Mazda 6 GH Admin — фон, утверждённый дизайн.

admin_gh_fullscreen_background.jpg — отдельная фоновая картинка, на всю высоту экрана.
admin_design_reference.png — полный утверждённый визуальный макет.

Для интеграции Android:
1. Поместить JPG в app/src/main/res/drawable-nodpi/.
2. В standalone Admin home установить ImageView MATCH_PARENT по ширине и высоте с CENTER_CROP в корневом FrameLayout, а существующий LinearLayout с шестью кнопками поверх него.
3. Оставить кнопки настоящими Android Button с существующими обработчиками нажатий. Использовать существующий admin_metal_button.xml, увеличить их визуальное соответствие макету.
4. Не применять фоновую картинку к основному приложению Studio.
5. Проверить на устройстве, что нижняя Mazda GH не обрезана критично.

Это комплект ресурсов, не собранный APK.
