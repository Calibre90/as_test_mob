Mazda 6 GH AS-BUILT STUDIO — UI assets
header_mazda_no_lock.png — верхний баннер без кнопки
admin_lock_button.png — отдельная кнопка замка
Оба PNG с прозрачностью вокруг внешнего контура.
